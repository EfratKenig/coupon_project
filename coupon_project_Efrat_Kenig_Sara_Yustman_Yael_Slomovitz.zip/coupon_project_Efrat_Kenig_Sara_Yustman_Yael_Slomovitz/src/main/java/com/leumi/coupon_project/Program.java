package com.leumi.coupon_project;

import java.sql.SQLException;

import static com.leumi.coupon_project.test.Test.testAll;

public class Program {
    public static void main(String[] args) throws Exception {
        testAll();
    }
}
